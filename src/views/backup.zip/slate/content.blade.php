<!-- content.blade.php used for ajax calls where only the content is required --> 
        
<!-- Content -->
@yield('content')
<!-- ./ content -->

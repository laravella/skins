@section('footer')
<div class="container" id="footer">
	<small>
			<a style="color:#c0c0c0" href="http://laravella.github.io/docs/">laravella</a>
	</small>
</div><!-- End #footer -->
@stop
{{-------------------------------------------------------- widget.input --------------}}
@section('input') 
    <div class="span4"><a href="{{$record[$field['name']]}}">{{$record[$field['name']]}}</a></div>
@show


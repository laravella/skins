{{-------------------------------------------------------- getIndex --------------}}

@section('getIndex')
@if($action == 'getIndex')
<h1>Index</h1>
<ul>
    <li><a href="/db/select/_db_tables">List Tables</a></li>
</ul>
@endif
@stop

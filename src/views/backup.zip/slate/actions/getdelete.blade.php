{{-------------------------------------------------------- getDelete --------------}}

@section('getDelete')
    @if($action == 'getDelete')
    'success'
    @endif
@stop
